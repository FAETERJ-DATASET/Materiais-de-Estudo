package model;

public class ConexaoBD {

}
